AI Lab Final Exam Code Pack

Practice priority:
1. lab08_alphaBeta_tree.py and lab08_coinProblem_alphaBeta.py
2. lab08_ticTacToe_minimax.py
3. lab07_csp_all_different.py and lab07_shiftAssignment_csp.py
4. lab09_studentPerformance_bayesianNetwork.py and lab09_diseaseSymptoms_bayesianNetwork.py
5. lab09_weather_markovModel.py
6. lab10_supervised_classification_models.py and lab10_supervised_linearRegression.py
7. lab10_unsupervised_studentClustering_elbow.py and vehicle/customer KMeans files

How to edit in exam:
- Search for "CHANGE HERE" in every file.
- Replace dataset name, target column, variables, constraints, states, probabilities, or K value.
- Keep the flow same: load/define data -> preprocess/model -> solve/train/query -> print output.


FAIL-SAFE EXTRA FILES ADDED:
- lab07_nQueens_csp.py
- lab07_csp_status_infeasible_failsafe.py
- lab07_dronePath_ucs.py
- lab09_burglaryAlarm_bayesianNetwork.py
- lab09_montyHall_bayesianNetwork.py
- lab09_generic_markovChain_failsafe.py
- lab10_supervised_decisionTree_classifier.py
- lab10_supervised_classification_evaluation_failsafe.py
- lab10_supervised_regression_metrics_failsafe.py
- lab10_supervised_loocv_failsafe.py
- lab10_unsupervised_pca_dimensionalityReduction.py
- lab10_eda_full_template_failsafe.py
