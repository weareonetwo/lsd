"""
Lab 07 CSP - All Different Template
Exam use: variables + domains + constraints + print solutions.
Install if needed: pip install ortools
"""
from ortools.sat.python import cp_model

# ===================== CHANGE HERE =====================
VARIABLE_NAMES = ["a", "b", "c"]
DOMAIN_MIN = 1
DOMAIN_MAX = 3
# Add pairs that must be different. Example: ("a", "b") means a != b
NOT_EQUAL_PAIRS = [("a", "b"), ("b", "c"), ("a", "c")]
# =======================================================

model = cp_model.CpModel()
vars_dict = {name: model.NewIntVar(DOMAIN_MIN, DOMAIN_MAX, name) for name in VARIABLE_NAMES}

for left, right in NOT_EQUAL_PAIRS:
    model.Add(vars_dict[left] != vars_dict[right])

solver = cp_model.CpSolver()
printer = cp_model.VarArraySolutionPrinter([vars_dict[name] for name in VARIABLE_NAMES])
solver.parameters.enumerate_all_solutions = True
status = solver.Solve(model, printer)

status_names = {
    cp_model.OPTIMAL: "OPTIMAL",
    cp_model.FEASIBLE: "FEASIBLE",
    cp_model.INFEASIBLE: "INFEASIBLE",
    cp_model.UNKNOWN: "UNKNOWN",
}
print("Status:", status_names.get(status, status))
