"""
Lab 07 Fail-Safe: CSP Status Checker
Exam pattern: teacher may give conflicting constraints and ask if feasible/infeasible.

CHANGE HERE:
- variables domains
- constraints
"""

from ortools.sat.python import cp_model

model = cp_model.CpModel()

x = model.NewIntVar(0, 2, "x")
y = model.NewIntVar(0, 2, "y")
z = model.NewIntVar(0, 2, "z")

# CHANGE HERE: add/remove constraints
model.Add(x != y)
model.Add(x == y)   # conflict example: makes model infeasible
model.Add(z == 0)

solver = cp_model.CpSolver()
status = solver.Solve(model)

status_mapping = {
    cp_model.OPTIMAL: "OPTIMAL",
    cp_model.FEASIBLE: "FEASIBLE",
    cp_model.INFEASIBLE: "INFEASIBLE",
    cp_model.UNKNOWN: "UNKNOWN",
}

print("Solver Status:", status_mapping.get(status, "UNKNOWN"))

if status in (cp_model.OPTIMAL, cp_model.FEASIBLE):
    print("x =", solver.Value(x))
    print("y =", solver.Value(y))
    print("z =", solver.Value(z))
else:
    print("No feasible solution found.")
