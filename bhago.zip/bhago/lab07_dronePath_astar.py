"""
Lab 07 CSP/Path Planning Style - Drone Path Planner using A*
Exam use: grid, start, goal, valid moves, shortest path.
1 = open cell, 0 = obstacle.
"""
import heapq
import math

# ===================== CHANGE HERE =====================
GRID = [
    [1, 1, 1, 1, 1],
    [1, 0, 0, 1, 1],
    [1, 1, 1, 1, 0],
    [0, 1, 0, 1, 1],
    [1, 1, 1, 0, 1],
]
START = (0, 0)
GOAL = (4, 4)
ALLOW_DIAGONAL = True
# =======================================================

straight = [(-1,0), (1,0), (0,-1), (0,1)]
diagonal = [(-1,-1), (-1,1), (1,-1), (1,1)]
DIRECTIONS = straight + diagonal if ALLOW_DIAGONAL else straight


def heuristic(a, b):
    """Euclidean distance using Pythagoras."""
    return math.sqrt((a[0]-b[0])**2 + (a[1]-b[1])**2)


def is_valid(pos):
    r, c = pos
    return 0 <= r < len(GRID) and 0 <= c < len(GRID[0]) and GRID[r][c] == 1


def astar(start, goal):
    pq = [(0, start)]
    parent = {start: None}
    g_cost = {start: 0}

    while pq:
        _, current = heapq.heappop(pq)
        if current == goal:
            break

        for dr, dc in DIRECTIONS:
            nxt = (current[0] + dr, current[1] + dc)
            if not is_valid(nxt):
                continue
            step_cost = math.sqrt(2) if dr != 0 and dc != 0 else 1
            new_cost = g_cost[current] + step_cost
            if nxt not in g_cost or new_cost < g_cost[nxt]:
                g_cost[nxt] = new_cost
                priority = new_cost + heuristic(nxt, goal)
                heapq.heappush(pq, (priority, nxt))
                parent[nxt] = current

    if goal not in parent:
        return None, math.inf

    path = []
    cur = goal
    while cur is not None:
        path.append(cur)
        cur = parent[cur]
    path.reverse()
    return path, g_cost[goal]


path, cost = astar(START, GOAL)
print("Path:", path)
print("Cost:", round(cost, 2))
