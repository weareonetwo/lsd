"""
Lab 07 Fail-Safe: Drone Path using Uniform Cost Search
Exam pattern: grid path planning with obstacles and shortest path.

CHANGE HERE:
- grid
- start
- goal
- directions
"""

import heapq
import math

class DronePathPlanner:
    def __init__(self, grid, start, goal):
        self.grid = grid
        self.start = start
        self.goal = goal
        self.rows = len(grid)
        self.cols = len(grid[0])

        # CHANGE HERE: allowed moves
        self.directions = [
            (-1, 0), (1, 0), (0, -1), (0, 1),
            (-1, -1), (-1, 1), (1, -1), (1, 1)
        ]

    def is_valid(self, r, c):
        return 0 <= r < self.rows and 0 <= c < self.cols and self.grid[r][c] == 1

    def move_cost(self, dr, dc):
        # diagonal cost = sqrt(2), straight cost = 1
        return math.sqrt(2) if dr != 0 and dc != 0 else 1

    def ucs(self):
        pq = [(0, self.start)]
        parent = {self.start: None}
        cost_so_far = {self.start: 0}

        while pq:
            current_cost, current = heapq.heappop(pq)

            if current == self.goal:
                return self.reconstruct_path(parent), current_cost

            r, c = current
            for dr, dc in self.directions:
                nr, nc = r + dr, c + dc
                if self.is_valid(nr, nc):
                    new_cost = current_cost + self.move_cost(dr, dc)
                    next_node = (nr, nc)

                    if next_node not in cost_so_far or new_cost < cost_so_far[next_node]:
                        cost_so_far[next_node] = new_cost
                        parent[next_node] = current
                        heapq.heappush(pq, (new_cost, next_node))

        return None, None

    def reconstruct_path(self, parent):
        path = []
        node = self.goal
        while node is not None:
            path.append(node)
            node = parent[node]
        return path[::-1]

grid = [
    [1, 1, 1, 1],
    [1, 0, 1, 1],
    [1, 1, 1, 0],
    [1, 1, 1, 1],
]

start = (0, 0)
goal = (3, 3)

planner = DronePathPlanner(grid, start, goal)
path, cost = planner.ucs()

print("Path:", path)
print("Cost:", cost)
