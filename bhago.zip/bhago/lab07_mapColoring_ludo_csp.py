"""
Lab 07 CSP - Map Coloring / Ludo Unique Colors
Exam use: assign different colors to players/regions using CSP.
"""
from ortools.sat.python import cp_model

# ===================== CHANGE HERE =====================
PLAYERS = ["Player_1", "Player_2", "Player_3", "Player_4"]
COLORS = ["Red", "Blue", "Green", "Yellow"]
# Conflicting pairs cannot share same color
CONFLICTS = [("Player_1", "Player_2"), ("Player_2", "Player_3"), ("Player_1", "Player_3")]
# =======================================================

model = cp_model.CpModel()
color_var = {p: model.NewIntVar(0, len(COLORS)-1, p) for p in PLAYERS}

for p1, p2 in CONFLICTS:
    model.Add(color_var[p1] != color_var[p2])

solver = cp_model.CpSolver()
status = solver.Solve(model)

if status in (cp_model.OPTIMAL, cp_model.FEASIBLE):
    for p in PLAYERS:
        print(p, "=", COLORS[solver.Value(color_var[p])])
else:
    print("No solution found.")
