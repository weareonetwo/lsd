"""
Lab 07 Fail-Safe: N-Queens CSP using OR-Tools
Exam pattern: "Place N queens on NxN board so no two attack each other."

CHANGE HERE:
- N = board size
"""

from ortools.sat.python import cp_model

N = 8  # CHANGE HERE

model = cp_model.CpModel()

# queens[col] = row position of queen in that column
queens = [model.NewIntVar(0, N - 1, f"queen_col_{c}") for c in range(N)]

# No two queens in same row
model.AddAllDifferent(queens)

# No two queens on same diagonal
for c1 in range(N):
    for c2 in range(c1 + 1, N):
        # diagonal attack condition: abs(row1-row2) != abs(col1-col2)
        model.Add(queens[c1] - queens[c2] != c1 - c2)
        model.Add(queens[c1] - queens[c2] != c2 - c1)

solver = cp_model.CpSolver()
status = solver.Solve(model)

if status in (cp_model.OPTIMAL, cp_model.FEASIBLE):
    print("Solution found:")
    board = [["." for _ in range(N)] for _ in range(N)]
    for col in range(N):
        row = solver.Value(queens[col])
        board[row][col] = "Q"
    for row in board:
        print(" ".join(row))
else:
    print("No solution found.")
