"""
Lab 07 CSP - Employee Shift Assignment
Exam use: change employees, shifts, and constraints.
"""
from ortools.sat.python import cp_model

# ===================== CHANGE HERE =====================
EMPLOYEES = ["Alice", "Bob", "Charlie"]
SHIFT_MIN = 0
SHIFT_MAX = 2
# Example constraints:
# Alice and Bob cannot have same shift; Bob cannot be shift 0
NOT_EQUAL_PAIRS = [("Alice", "Bob")]
NOT_ALLOWED = [("Bob", 0)]
# =======================================================

model = cp_model.CpModel()
shift = {emp: model.NewIntVar(SHIFT_MIN, SHIFT_MAX, emp) for emp in EMPLOYEES}

for e1, e2 in NOT_EQUAL_PAIRS:
    model.Add(shift[e1] != shift[e2])

for emp, bad_shift in NOT_ALLOWED:
    model.Add(shift[emp] != bad_shift)

solver = cp_model.CpSolver()
printer = cp_model.VarArraySolutionPrinter([shift[e] for e in EMPLOYEES])
solver.parameters.enumerate_all_solutions = True
status = solver.Solve(model, printer)

if status in (cp_model.OPTIMAL, cp_model.FEASIBLE):
    print("Solutions printed above.")
else:
    print("No feasible solution found.")
