"""
Lab 07 CSP - 4x4 Sudoku Template
Exam use: complete assignment with row/column/sub-grid uniqueness.
0 means empty cell.
"""
from ortools.sat.python import cp_model

# ===================== CHANGE HERE =====================
GRID = [
    [1, 0, 0, 4],
    [0, 0, 1, 0],
    [0, 3, 0, 0],
    [2, 0, 0, 3],
]
N = 4
SUB = 2
# =======================================================

model = cp_model.CpModel()
cell = [[model.NewIntVar(1, N, f"r{r}c{c}") for c in range(N)] for r in range(N)]

# Given values
for r in range(N):
    for c in range(N):
        if GRID[r][c] != 0:
            model.Add(cell[r][c] == GRID[r][c])

# Rows and columns must be all different
for i in range(N):
    model.AddAllDifferent(cell[i])
    model.AddAllDifferent([cell[r][i] for r in range(N)])

# Sub-grids must be all different
for br in range(0, N, SUB):
    for bc in range(0, N, SUB):
        block = [cell[r][c] for r in range(br, br+SUB) for c in range(bc, bc+SUB)]
        model.AddAllDifferent(block)

solver = cp_model.CpSolver()
status = solver.Solve(model)

if status in (cp_model.OPTIMAL, cp_model.FEASIBLE):
    for r in range(N):
        print([solver.Value(cell[r][c]) for c in range(N)])
else:
    print("No solution found.")
