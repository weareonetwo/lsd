"""
Lab 08 Adversarial Search - Alpha-Beta Pruning on Game Tree
Exam use: same as minimax, but skips useless branches.
"""
import math

# ===================== CHANGE HERE =====================
LEAF_VALUES = [2, 3, 5, 9, 0, 1, 7, 5]
DEPTH = 3
# =======================================================

visited = []
pruned = []


def alpha_beta(index, depth, alpha, beta, maximizing):
    if depth == 0:
        visited.append((index, LEAF_VALUES[index]))
        return LEAF_VALUES[index]

    if maximizing:
        best = -math.inf
        for child in range(2):
            value = alpha_beta(index * 2 + child, depth - 1, alpha, beta, False)
            best = max(best, value)
            alpha = max(alpha, best)
            if beta <= alpha:
                pruned.append(f"Pruned remaining children of node index {index}")
                break
        return best
    else:
        best = math.inf
        for child in range(2):
            value = alpha_beta(index * 2 + child, depth - 1, alpha, beta, True)
            best = min(best, value)
            beta = min(beta, best)
            if beta <= alpha:
                pruned.append(f"Pruned remaining children of node index {index}")
                break
        return best


best_value = alpha_beta(0, DEPTH, -math.inf, math.inf, True)
print("Best Value:", best_value)
print("Visited Leaves:", visited)
print("Pruning Notes:", pruned)
