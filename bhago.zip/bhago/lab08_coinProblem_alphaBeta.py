"""
Lab 08 Task 02 - Coin Picking Game using Minimax + Alpha-Beta
Two players pick leftmost or rightmost coin. Max wants max score.
"""
import math

# ===================== CHANGE HERE =====================
COINS = [3, 9, 1, 2, 7, 5]
# =======================================================


def best_max_score(coins, left, right, alpha, beta, max_turn):
    """Returns the best total score Max can still collect from coins[left:right+1]."""
    if left > right:
        return 0

    if max_turn:
        # Max gets the coin value
        pick_left = coins[left] + best_max_score(coins, left + 1, right, alpha, beta, False)
        alpha = max(alpha, pick_left)
        pick_right = coins[right] + best_max_score(coins, left, right - 1, alpha, beta, False)
        return max(pick_left, pick_right)
    else:
        # Min does not add to Max score; Min chooses move that minimizes Max's final score
        pick_left = best_max_score(coins, left + 1, right, alpha, beta, True)
        beta = min(beta, pick_left)
        if beta <= alpha:
            return pick_left
        pick_right = best_max_score(coins, left, right - 1, alpha, beta, True)
        return min(pick_left, pick_right)


def play_game(coins):
    left, right = 0, len(coins) - 1
    max_score = 0
    min_score = 0
    max_turn = True

    print("Initial Coins:", coins)
    while left <= right:
        if max_turn:
            # Compare future result if Max picks left vs right
            left_score = coins[left] + best_max_score(coins, left + 1, right, -math.inf, math.inf, False)
            right_score = coins[right] + best_max_score(coins, left, right - 1, -math.inf, math.inf, False)
            if left_score >= right_score:
                pick = coins[left]
                left += 1
            else:
                pick = coins[right]
                right -= 1
            max_score += pick
            print(f"Max picks {pick}, Remaining Coins: {coins[left:right+1]}")
        else:
            # Simple Min strategy from manual: pick smaller edge coin
            if coins[left] <= coins[right]:
                pick = coins[left]
                left += 1
            else:
                pick = coins[right]
                right -= 1
            min_score += pick
            print(f"Min picks {pick}, Remaining Coins: {coins[left:right+1]}")
        max_turn = not max_turn

    print(f"Final Scores - Max: {max_score}, Min: {min_score}")
    print("Winner:", "Max" if max_score > min_score else "Min" if min_score > max_score else "Draw")


play_game(COINS)
