"""
Lab 08 Adversarial Search - Minimax on Game Tree
Exam use: change leaf values and tree depth.
"""
import math

# ===================== CHANGE HERE =====================
# Leaves are grouped as a binary tree. Depth 3 means 8 leaves.
LEAF_VALUES = [2, 3, 5, 9, 0, 1, 7, 5]
DEPTH = 3
# =======================================================


def minimax(index, depth, maximizing):
    # index tells which subtree we are currently exploring
    if depth == 0:
        return LEAF_VALUES[index]

    if maximizing:
        best = -math.inf
        for child in range(2):
            value = minimax(index * 2 + child, depth - 1, False)
            best = max(best, value)
        return best
    else:
        best = math.inf
        for child in range(2):
            value = minimax(index * 2 + child, depth - 1, True)
            best = min(best, value)
        return best


best_value = minimax(0, DEPTH, True)
print("Leaf Values:", LEAF_VALUES)
print("Minimax Best Value:", best_value)
