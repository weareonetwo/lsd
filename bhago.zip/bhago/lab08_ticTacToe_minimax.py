"""
Lab 08 Task 01 - Tic Tac Toe AI using Minimax
AI = X, Human = O. For exam, understand check_winner, minimax, best_move.
"""
import math

AI = "X"
HUMAN = "O"
EMPTY = " "

board = [[EMPTY for _ in range(3)] for _ in range(3)]


def print_board():
    for row in board:
        print(" | ".join(row))
        print("---------")


def check_winner():
    lines = []
    lines.extend(board)
    lines.extend([[board[r][c] for r in range(3)] for c in range(3)])
    lines.append([board[i][i] for i in range(3)])
    lines.append([board[i][2-i] for i in range(3)])

    for line in lines:
        if line == [AI, AI, AI]:
            return AI
        if line == [HUMAN, HUMAN, HUMAN]:
            return HUMAN

    if all(board[r][c] != EMPTY for r in range(3) for c in range(3)):
        return "Draw"
    return None


def minimax(is_maximizing):
    result = check_winner()
    if result == AI:
        return 1
    if result == HUMAN:
        return -1
    if result == "Draw":
        return 0

    if is_maximizing:
        best = -math.inf
        for r in range(3):
            for c in range(3):
                if board[r][c] == EMPTY:
                    board[r][c] = AI
                    best = max(best, minimax(False))
                    board[r][c] = EMPTY
        return best
    else:
        best = math.inf
        for r in range(3):
            for c in range(3):
                if board[r][c] == EMPTY:
                    board[r][c] = HUMAN
                    best = min(best, minimax(True))
                    board[r][c] = EMPTY
        return best


def best_move():
    best_score = -math.inf
    move = None
    for r in range(3):
        for c in range(3):
            if board[r][c] == EMPTY:
                board[r][c] = AI
                score = minimax(False)
                board[r][c] = EMPTY
                if score > best_score:
                    best_score = score
                    move = (r, c)
    return move


while True:
    print_board()
    winner = check_winner()
    if winner:
        print("Result:", winner)
        break

    row = int(input("Enter row 0-2: "))
    col = int(input("Enter col 0-2: "))
    if board[row][col] != EMPTY:
        print("Invalid move. Try again.")
        continue
    board[row][col] = HUMAN

    winner = check_winner()
    if winner:
        continue

    r, c = best_move()
    board[r][c] = AI
    print(f"AI placed X at ({r}, {c})")
