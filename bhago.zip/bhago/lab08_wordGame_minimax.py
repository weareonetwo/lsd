"""
Lab 08 Task 04 - Word Game using Minimax
Players pick letters to form a word. Score = length if valid, penalty if invalid.
This is a simple exam-friendly template.
"""
import math

# ===================== CHANGE HERE =====================
LETTERS = list("CART")
VALID_WORDS = {"CAR", "CAT", "ART", "RAT", "TAR", "CART"}
MAX_DEPTH = 4
INVALID_PENALTY = -2
# =======================================================


def evaluate(current_word):
    if current_word in VALID_WORDS:
        return len(current_word)
    # partial valid prefix gets small reward, invalid final gets penalty
    if any(word.startswith(current_word) for word in VALID_WORDS):
        return 0
    return INVALID_PENALTY


def minimax(remaining, current_word, depth, maximizing):
    if depth == 0 or not remaining:
        return evaluate(current_word)

    if maximizing:
        best = -math.inf
        for i, letter in enumerate(remaining):
            new_remaining = remaining[:i] + remaining[i+1:]
            best = max(best, minimax(new_remaining, current_word + letter, depth - 1, False))
        return best
    else:
        best = math.inf
        for i, letter in enumerate(remaining):
            new_remaining = remaining[:i] + remaining[i+1:]
            best = min(best, minimax(new_remaining, current_word + letter, depth - 1, True))
        return best


best_letter = None
best_score = -math.inf
for i, letter in enumerate(LETTERS):
    score = minimax(LETTERS[:i] + LETTERS[i+1:], letter, MAX_DEPTH - 1, False)
    if score > best_score:
        best_score = score
        best_letter = letter

print("Available Letters:", LETTERS)
print("Best first letter for Max:", best_letter)
print("Expected score:", best_score)
