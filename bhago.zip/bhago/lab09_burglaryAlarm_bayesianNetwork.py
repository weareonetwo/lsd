"""
Lab 09 Fail-Safe: Burglary Alarm Bayesian Network
Exam pattern: Given John and Mary called, find probability of Burglary.

CHANGE HERE:
- CPD probabilities
- evidence in infer.query()
"""

# pip install pgmpy
from pgmpy.models import DiscreteBayesianNetwork
from pgmpy.factors.discrete import TabularCPD
from pgmpy.inference import VariableElimination

model = DiscreteBayesianNetwork([
    ("Burglary", "Alarm"),
    ("Earthquake", "Alarm"),
    ("Alarm", "JohnCalls"),
    ("Alarm", "MaryCalls"),
])

cpd_b = TabularCPD("Burglary", 2, [[0.999], [0.001]], state_names={"Burglary": ["False", "True"]})
cpd_e = TabularCPD("Earthquake", 2, [[0.998], [0.002]], state_names={"Earthquake": ["False", "True"]})

# Alarm values: False row, True row
# evidence order: Burglary, Earthquake
cpd_a = TabularCPD(
    "Alarm", 2,
    values=[
        [0.999, 0.71, 0.06, 0.05],  # Alarm=False
        [0.001, 0.29, 0.94, 0.95],  # Alarm=True
    ],
    evidence=["Burglary", "Earthquake"],
    evidence_card=[2, 2],
    state_names={
        "Alarm": ["False", "True"],
        "Burglary": ["False", "True"],
        "Earthquake": ["False", "True"],
    },
)

cpd_j = TabularCPD(
    "JohnCalls", 2,
    [[0.95, 0.10], [0.05, 0.90]],
    evidence=["Alarm"],
    evidence_card=[2],
    state_names={"JohnCalls": ["False", "True"], "Alarm": ["False", "True"]},
)

cpd_m = TabularCPD(
    "MaryCalls", 2,
    [[0.99, 0.30], [0.01, 0.70]],
    evidence=["Alarm"],
    evidence_card=[2],
    state_names={"MaryCalls": ["False", "True"], "Alarm": ["False", "True"]},
)

model.add_cpds(cpd_b, cpd_e, cpd_a, cpd_j, cpd_m)
print("Model valid?", model.check_model())

infer = VariableElimination(model)

result = infer.query(
    variables=["Burglary"],
    evidence={"JohnCalls": "True", "MaryCalls": "True"}  # CHANGE HERE
)

print(result)
