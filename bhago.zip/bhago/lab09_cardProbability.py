"""
Lab 09 Task 01 - Card Probability
Exam use: conditional probability from a 52-card deck.
"""

suits = ["Hearts", "Diamonds", "Clubs", "Spades"]
ranks = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King", "Ace"]
deck = [(rank, suit) for suit in suits for rank in ranks]

red_cards = [card for card in deck if card[1] in ["Hearts", "Diamonds"]]
face_cards = [card for card in deck if card[0] in ["Jack", "Queen", "King"]]

p_red = len(red_cards) / len(deck)
p_heart_given_red = len([c for c in red_cards if c[1] == "Hearts"]) / len(red_cards)
p_diamond_given_face = len([c for c in face_cards if c[1] == "Diamonds"]) / len(face_cards)

# P(Spade OR Queen | Face) = face cards that are spade OR queen / all face cards
spade_or_queen_face = [c for c in face_cards if c[1] == "Spades" or c[0] == "Queen"]
p_spade_or_queen_given_face = len(spade_or_queen_face) / len(face_cards)

print("P(Red):", p_red)
print("P(Heart | Red):", p_heart_given_red)
print("P(Diamond | Face):", p_diamond_given_face)
print("P(Spade OR Queen | Face):", p_spade_or_queen_given_face)
