"""
Lab 09 Task 03 - Disease Prediction Bayesian Network
Disease -> Fever, Cough, Fatigue, Chills
Install if needed: pip install pgmpy
"""
from pgmpy.models import DiscreteBayesianNetwork
from pgmpy.factors.discrete import TabularCPD
from pgmpy.inference import VariableElimination

model = DiscreteBayesianNetwork([
    ("Disease", "Fever"),
    ("Disease", "Cough"),
    ("Disease", "Fatigue"),
    ("Disease", "Chills"),
])

# Disease states: Flu, Cold
cpd_disease = TabularCPD("Disease", 2, [[0.3], [0.7]], state_names={"Disease": ["Flu", "Cold"]})

# Each symptom CPD order: Yes row, No row; columns: Flu, Cold
cpd_fever = TabularCPD("Fever", 2, [[0.9, 0.5], [0.1, 0.5]], evidence=["Disease"], evidence_card=[2],
                       state_names={"Fever": ["Yes", "No"], "Disease": ["Flu", "Cold"]})
cpd_cough = TabularCPD("Cough", 2, [[0.8, 0.6], [0.2, 0.4]], evidence=["Disease"], evidence_card=[2],
                       state_names={"Cough": ["Yes", "No"], "Disease": ["Flu", "Cold"]})
cpd_fatigue = TabularCPD("Fatigue", 2, [[0.7, 0.3], [0.3, 0.7]], evidence=["Disease"], evidence_card=[2],
                         state_names={"Fatigue": ["Yes", "No"], "Disease": ["Flu", "Cold"]})
cpd_chills = TabularCPD("Chills", 2, [[0.6, 0.4], [0.4, 0.6]], evidence=["Disease"], evidence_card=[2],
                        state_names={"Chills": ["Yes", "No"], "Disease": ["Flu", "Cold"]})

model.add_cpds(cpd_disease, cpd_fever, cpd_cough, cpd_fatigue, cpd_chills)
print("Model valid:", model.check_model())

infer = VariableElimination(model)

print("\nP(Disease | Fever=Yes, Cough=Yes)")
print(infer.query(variables=["Disease"], evidence={"Fever": "Yes", "Cough": "Yes"}))

print("\nP(Disease | Fever=Yes, Cough=Yes, Chills=Yes)")
print(infer.query(variables=["Disease"], evidence={"Fever": "Yes", "Cough": "Yes", "Chills": "Yes"}))

print("\nP(Fatigue | Disease=Flu)")
print(infer.query(variables=["Fatigue"], evidence={"Disease": "Flu"}))
