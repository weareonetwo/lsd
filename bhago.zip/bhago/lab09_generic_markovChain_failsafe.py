"""
Lab 09 Fail-Safe: Generic Markov Chain Simulator
Exam pattern: simulate weather/marble/customer states using transition matrix.

CHANGE HERE:
- states
- transition_matrix rows
- initial_state
"""

import numpy as np

states = ["Red", "Blue"]  # CHANGE HERE

transition_matrix = np.array([
    [0.5, 0.5],  # From Red -> Red, Blue
    [0.5, 0.5],  # From Blue -> Red, Blue
])

def simulate_markov_chain(initial_state, steps):
    current_state = initial_state
    sequence = [current_state]

    for _ in range(steps):
        row_index = states.index(current_state)
        current_state = np.random.choice(states, p=transition_matrix[row_index])
        sequence.append(current_state)

    return sequence

print(simulate_markov_chain(initial_state="Red", steps=10))
