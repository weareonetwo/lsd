"""
Lab 09 Fail-Safe: Monty Hall Bayesian Network
Exam pattern: Guest chooses door, Monty opens door, infer prize location.
"""

# pip install pgmpy
from pgmpy.models import DiscreteBayesianNetwork
from pgmpy.factors.discrete import TabularCPD
from pgmpy.inference import VariableElimination

model = DiscreteBayesianNetwork([
    ("Guest", "Monty"),
    ("Prize", "Monty"),
])

cpd_guest = TabularCPD("Guest", 3, [[1/3], [1/3], [1/3]], state_names={"Guest": [1, 2, 3]})
cpd_prize = TabularCPD("Prize", 3, [[1/3], [1/3], [1/3]], state_names={"Prize": [1, 2, 3]})

cpd_monty = TabularCPD(
    "Monty", 3,
    values=[
        [0,   0,   0,   0,   1,   0.5, 0,   0.5, 1],
        [0.5, 0,   1,   0,   0,   0,   1,   0.5, 0],
        [0.5, 1,   0,   1,   0,   0.5, 0,   0,   0],
    ],
    evidence=["Guest", "Prize"],
    evidence_card=[3, 3],
    state_names={"Monty": [1, 2, 3], "Guest": [1, 2, 3], "Prize": [1, 2, 3]},
)

model.add_cpds(cpd_guest, cpd_prize, cpd_monty)
print("Model valid?", model.check_model())

infer = VariableElimination(model)

# CHANGE HERE: evidence
result = infer.query(variables=["Prize"], evidence={"Guest": 1, "Monty": 3})
print(result)
print("Stick with door 1:", result.values[0])
print("Switch to door 2:", result.values[1])
