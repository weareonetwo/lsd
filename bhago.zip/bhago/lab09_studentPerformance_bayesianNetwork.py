"""
Lab 09 Task 02 - Student Exam Performance Bayesian Network
Install if needed: pip install pgmpy
Exam use: structure + CPDs + VariableElimination queries.
"""
from pgmpy.models import DiscreteBayesianNetwork
from pgmpy.factors.discrete import TabularCPD
from pgmpy.inference import VariableElimination

# Structure: I, S, D -> G -> P
model = DiscreteBayesianNetwork([
    ("Intelligence", "Grade"),
    ("StudyHours", "Grade"),
    ("Difficulty", "Grade"),
    ("Grade", "Pass"),
])

# Root CPDs
cpd_i = TabularCPD("Intelligence", 2, [[0.7], [0.3]], state_names={"Intelligence": ["High", "Low"]})
cpd_s = TabularCPD("StudyHours", 2, [[0.6], [0.4]], state_names={"StudyHours": ["Sufficient", "Insufficient"]})
cpd_d = TabularCPD("Difficulty", 2, [[0.4], [0.6]], state_names={"Difficulty": ["Hard", "Easy"]})

# ===================== CHANGE HERE IF TEACHER GIVES CPT =====================
# Grade states: A, B, C
# Evidence order columns: Intelligence x StudyHours x Difficulty
# I=High/Low, S=Sufficient/Insufficient, D=Hard/Easy
cpd_g = TabularCPD(
    variable="Grade",
    variable_card=3,
    values=[
        # A probabilities
        [0.70, 0.90, 0.45, 0.65, 0.30, 0.50, 0.10, 0.25],
        # B probabilities
        [0.20, 0.08, 0.35, 0.25, 0.40, 0.35, 0.30, 0.35],
        # C probabilities
        [0.10, 0.02, 0.20, 0.10, 0.30, 0.15, 0.60, 0.40],
    ],
    evidence=["Intelligence", "StudyHours", "Difficulty"],
    evidence_card=[2, 2, 2],
    state_names={
        "Grade": ["A", "B", "C"],
        "Intelligence": ["High", "Low"],
        "StudyHours": ["Sufficient", "Insufficient"],
        "Difficulty": ["Hard", "Easy"],
    },
)
# ============================================================================

cpd_p = TabularCPD(
    "Pass", 2,
    [[0.95, 0.80, 0.50],  # Yes
     [0.05, 0.20, 0.50]], # No
    evidence=["Grade"],
    evidence_card=[3],
    state_names={"Pass": ["Yes", "No"], "Grade": ["A", "B", "C"]},
)

model.add_cpds(cpd_i, cpd_s, cpd_d, cpd_g, cpd_p)
print("Model valid:", model.check_model())

infer = VariableElimination(model)

q1 = infer.query(variables=["Pass"], evidence={"StudyHours": "Sufficient", "Difficulty": "Hard"})
print("\nP(Pass | StudyHours=Sufficient, Difficulty=Hard)")
print(q1)

q2 = infer.query(variables=["Intelligence"], evidence={"Pass": "Yes"})
print("\nP(Intelligence | Pass=Yes)")
print(q2)
