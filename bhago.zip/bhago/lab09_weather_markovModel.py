"""
Lab 09 Task 04 - Markov Model Weather Simulation
States: Sunny, Cloudy, Rainy. Simulate 10 days and estimate P(at least 3 rainy days).
"""
import numpy as np

# ===================== CHANGE HERE =====================
states = ["Sunny", "Cloudy", "Rainy"]
transition_matrix = np.array([
    # To:    Sunny  Cloudy Rainy
    [0.60,   0.30,  0.10],  # From Sunny
    [0.30,   0.40,  0.30],  # From Cloudy
    [0.20,   0.30,  0.50],  # From Rainy
])
initial_state = "Sunny"
num_days = 10
simulation_runs = 10000
# =======================================================


def simulate_once(start_state, days):
    current = start_state
    sequence = [current]
    for _ in range(days):
        row = states.index(current)
        current = np.random.choice(states, p=transition_matrix[row])
        sequence.append(current)
    return sequence


seq = simulate_once(initial_state, num_days)
print(f"One weather sequence for {num_days} days:")
print(" -> ".join(seq))

count_at_least_3_rainy = 0
for _ in range(simulation_runs):
    seq = simulate_once(initial_state, num_days)
    rainy_count = seq[1:].count("Rainy")  # exclude initial day
    if rainy_count >= 3:
        count_at_least_3_rainy += 1

probability = count_at_least_3_rainy / simulation_runs
print("Estimated P(at least 3 rainy days):", probability)
