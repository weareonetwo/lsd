import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

sns.set(style="whitegrid")

# ----------------------------
# 1. LOAD DATASET (CHANGE THIS)
# ----------------------------
df = pd.read_csv("dataset.csv")  # ← change filename here
print("Dataset loaded!")
print("Rows:", df.shape[0])
print("Columns:", df.shape[1])

# ----------------------------
# 2. BASIC INFO (never changes)
# ----------------------------
print(df.dtypes)

num_cols = df.select_dtypes(include=['int64','float64']).columns.tolist()
cat_cols = df.select_dtypes(include=['object']).columns.tolist()
print("Numerical columns:", num_cols)
print("Categorical columns:", cat_cols)

# ----------------------------
# 3. MISSING VALUES (never changes)
# ----------------------------
print("Missing values per column:")
print(df.isnull().sum())

df.fillna(df.mean(numeric_only=True), inplace=True)
print("Missing values after filling:", df.isnull().sum().sum())

# ----------------------------
# 4. DUPLICATES (never changes)
# ----------------------------
print("Duplicates found:", df.duplicated().sum())
df.drop_duplicates(inplace=True)
df.reset_index(drop=True, inplace=True)
print("Shape after removing duplicates:", df.shape)

# ----------------------------
# 5. ENCODING (CHANGE THIS)
# ----------------------------
# If your binary columns have values 1 and 2, convert to 0 and 1
binary_cols = ['COL1', 'COL2', 'COL3']  # ← put your binary column names here
for col in binary_cols:
    df[col] = df[col] - 1

# Encode categorical columns manually
df['GENDER_ENC'] = df['GENDER'].map({'M': 1, 'F': 0})           # ← change as needed
df['TARGET_ENC'] = df['TARGET'].map({'YES': 1, 'NO': 0})        # ← change target column name

# ----------------------------
# 6. STATISTICS (never changes)
# ----------------------------
print("Mean:");    print(df.mean(numeric_only=True))
print("Median:");  print(df.median(numeric_only=True))
print("Std:");     print(df.std(numeric_only=True))
print("Min:");     print(df.min(numeric_only=True))
print("Max:");     print(df.max(numeric_only=True))

# ----------------------------
# 7. PLOTS (CHANGE column names only)
# ----------------------------

# Histogram for numerical column
plt.figure(figsize=(7, 4))
plt.hist(df['AGE'], bins=20, color='steelblue', edgecolor='white')  # ← change AGE
plt.title("Distribution")
plt.xlabel("Value")
plt.ylabel("Count")
plt.show()

# Count plot for target column
plt.figure(figsize=(6, 4))
sns.countplot(x='TARGET', data=df, hue='TARGET', palette='Set2', legend=False)  # ← change TARGET
plt.title("Target Class Distribution")
plt.show()

# Count plot for categorical column
plt.figure(figsize=(6, 4))
sns.countplot(x='GENDER', data=df, hue='GENDER', palette='pastel', legend=False)  # ← change GENDER
plt.title("Gender Distribution")
plt.show()

# Skewness
print("Skewness:")
print(df[binary_cols + ['AGE']].skew())  # ← change AGE

# Bar chart for binary feature proportions
symptom_means = df[binary_cols].mean().sort_values(ascending=False)
plt.figure(figsize=(12, 5))
symptom_means.plot(kind='bar', color='coral', edgecolor='white')
plt.title("Proportion of Each Feature")
plt.ylabel("Proportion")
plt.xticks(rotation=45, ha='right')
plt.tight_layout()
plt.show()

# Correlation heatmap
all_cols = binary_cols + ['AGE', 'TARGET_ENC']  # ← change AGE and TARGET_ENC
corr = df[all_cols].corr()
plt.figure(figsize=(12, 9))
sns.heatmap(corr, annot=True, fmt='.2f', cmap='coolwarm', linewidths=0.5)
plt.title("Correlation Heatmap")
plt.tight_layout()
plt.show()

# Boxplot numerical vs target
plt.figure(figsize=(7, 5))
sns.boxplot(x='TARGET', y='AGE', data=df, hue='TARGET',   # ← change TARGET and AGE
            palette={'YES': 'tomato', 'NO': 'steelblue'}, legend=False)
plt.title("Age vs Target")
plt.show()

# Bar chart average numerical by target
plt.figure(figsize=(7, 5))
sns.barplot(x='TARGET', y='AGE', data=df, hue='TARGET',   # ← change TARGET and AGE
            palette={'YES': 'tomato', 'NO': 'steelblue'}, legend=False)
plt.title("Average Age by Target")
plt.show()

# Symptom rates by target
symptom_rate = df.groupby('TARGET')[binary_cols].mean()   # ← change TARGET
symptom_rate.T.plot(kind='bar', figsize=(13, 5),
                    color=['steelblue','tomato'], edgecolor='white')
plt.title("Feature Rates by Target")
plt.xticks(rotation=45, ha='right')
plt.legend(title='Target')
plt.tight_layout()
plt.show()

# Pairplot
pairplot_cols = ['AGE', 'COL1', 'COL2', 'TARGET']   # ← change these
sns.pairplot(df[pairplot_cols], hue='TARGET',
             palette={'YES': 'tomato', 'NO': 'steelblue'}, plot_kws={'alpha': 0.4})
plt.suptitle("Pairplot by Target", y=1.02)
plt.show()

# Group means
group_means = df.groupby('TARGET')[binary_cols + ['AGE']].mean()  # ← change TARGET, AGE
print("Average values grouped by Target:")
print(group_means.T)

# Stacked bar — categorical breakdown by target
cat_target = df.groupby(['TARGET', 'GENDER']).size().unstack()   # ← change TARGET, GENDER
cat_target.plot(kind='bar', stacked=True, figsize=(7, 5),
                color=['salmon', 'steelblue'], edgecolor='white')
plt.title("Gender Breakdown by Target")
plt.xticks(rotation=0)
plt.tight_layout()
plt.show()

# ----------------------------
# 8. OUTLIER DETECTION (CHANGE column names only)
# ----------------------------

# Boxplot for numerical column
plt.figure(figsize=(6, 4))
sns.boxplot(y='AGE', data=df, color='lightcoral')   # ← change AGE
plt.title("Boxplot of AGE")
plt.show()

# IQR outlier check for all features
print("Features with outliers:")
found = False
for col in binary_cols + ['AGE']:    # ← change AGE
    Q1 = df[col].quantile(0.25)
    Q3 = df[col].quantile(0.75)
    IQR = Q3 - Q1
    count = ((df[col] < Q1 - 1.5*IQR) | (df[col] > Q3 + 1.5*IQR)).sum()
    if count > 0:
        print(f"{col}: {count} outliers")
        found = True
if not found:
    print("No outliers found.")

# Individual boxplots grid
fig, axes = plt.subplots(3, 5, figsize=(16, 9))
axes = axes.flatten()
all_features = binary_cols + ['AGE']   # ← change AGE
for i, col in enumerate(all_features):
    axes[i].boxplot(df[col].dropna())
    axes[i].set_title(col, fontsize=9)
for j in range(i+1, len(axes)):
    axes[j].set_visible(False)
plt.suptitle("Outlier Detection - All Features")
plt.tight_layout()
plt.show()

# Skewness labels
skewness = df[binary_cols + ['AGE']].skew()   # ← change AGE
for col in skewness.index:
    s = skewness[col]
    if abs(s) < 0.5:    label = "Normal"
    elif s > 0.5:       label = "Right skewed"
    else:               label = "Left skewed"
    print(f"{col}: skewness = {round(s, 3)}  -->  {label}")

# ----------------------------
# 9. FEATURE ENGINEERING (CHANGE THIS)
# ----------------------------

# Age group binning
df['AGE_GROUP'] = pd.cut(df['AGE'], bins=[29, 40, 55, 70, 81],   # ← change bins and AGE
                          labels=['30-40', '41-55', '56-70', '71-80'])

age_cancer = df.groupby(['AGE_GROUP', 'TARGET'], observed=True).size().unstack()  # ← change TARGET
age_cancer.plot(kind='bar', figsize=(9, 5),
                color=['steelblue','tomato'], edgecolor='white')
plt.title("Target Count by Age Group")
plt.xticks(rotation=0)
plt.tight_layout()
plt.show()

# Risk score — total symptoms per patient
df['RISK_SCORE'] = df[binary_cols].sum(axis=1)
plt.figure(figsize=(9, 5))
sns.histplot(data=df, x='RISK_SCORE', hue='TARGET',   # ← change TARGET
             multiple='dodge', palette={'YES': 'tomato', 'NO': 'steelblue'}, bins=14)
plt.title("Total Feature Count by Target")
plt.tight_layout()
plt.show()
print("Average score per group:")
print(df.groupby('TARGET')['RISK_SCORE'].mean())   # ← change TARGET

# Feature correlation with target
target_corr = df[binary_cols + ['AGE']].corrwith(df['TARGET_ENC']).abs().sort_values(ascending=False)  # ← change
plt.figure(figsize=(10, 5))
target_corr.plot(kind='bar', color='darkorange', edgecolor='white')
plt.title("Feature Correlation with Target")
plt.xticks(rotation=45, ha='right')
plt.tight_layout()
plt.show()
print("Top 5 features:")
print(target_corr.head(5))

# ----------------------------
# 10. SAVE CLEANED DATA (CHANGE THIS)
# ----------------------------
df_ml = df.drop(columns=['GENDER', 'TARGET', 'AGE_GROUP'])   # ← change columns to drop
df_ml.to_csv("dataset_cleaned.csv", index=False)
print("Saved! Shape:", df_ml.shape)