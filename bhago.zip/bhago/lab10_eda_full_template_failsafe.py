"""
Lab 10 Fail-Safe: Full EDA Template
Exam pattern: read dataset and perform basic data checks + simple visualizations.

CHANGE HERE:
- file_path
- target_column
"""

import pandas as pd
import matplotlib.pyplot as plt

file_path = "data.csv"  # CHANGE HERE
target_column = None    # CHANGE HERE e.g. "Species" or "target"

# df = pd.read_csv(file_path)
# For practice without file:
df = pd.DataFrame({
    "Age": [18, 20, 19, None, 21],
    "Score": [70, 85, 90, 75, None],
    "Gender": ["M", "F", "M", "F", "M"]
})

print("HEAD:")
print(df.head())

print("\nSHAPE:", df.shape)

print("\nINFO:")
print(df.info())

print("\nMISSING VALUES:")
print(df.isnull().sum())

print("\nDUPLICATES:", df.duplicated().sum())

print("\nDESCRIBE:")
print(df.describe())

print("\nUNIQUE VALUES:")
for col in df.columns:
    print(col, ":", df[col].nunique())

numeric_cols = df.select_dtypes(include=["int64", "float64"]).columns
categorical_cols = df.select_dtypes(include=["object"]).columns

print("\nNumeric Columns:", list(numeric_cols))
print("Categorical Columns:", list(categorical_cols))

# Fill missing values
for col in numeric_cols:
    df[col] = df[col].fillna(df[col].mean())

for col in categorical_cols:
    df[col] = df[col].fillna(df[col].mode()[0])

# Simple histogram
df[numeric_cols].hist()
plt.show()

# Correlation heatmap using pandas/matplotlib
print("\nCorrelation:")
print(df[numeric_cols].corr())
