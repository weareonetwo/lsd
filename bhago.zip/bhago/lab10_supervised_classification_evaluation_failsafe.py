"""
Lab 10 Fail-Safe: Classification Evaluation Metrics
Exam pattern: after prediction, calculate accuracy, precision, recall, F1, confusion matrix.
"""

from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix, classification_report

# CHANGE HERE: replace these with your actual y_test and y_pred
y_test = [1, 0, 1, 1, 0, 0]
y_pred = [1, 0, 1, 0, 0, 1]

print("Accuracy:", accuracy_score(y_test, y_pred))
print("Precision:", precision_score(y_test, y_pred, average="weighted"))
print("Recall:", recall_score(y_test, y_pred, average="weighted"))
print("F1 Score:", f1_score(y_test, y_pred, average="weighted"))
print("Confusion Matrix:\n", confusion_matrix(y_test, y_pred))
print("Classification Report:\n", classification_report(y_test, y_pred))
