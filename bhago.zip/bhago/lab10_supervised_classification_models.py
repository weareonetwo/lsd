"""
Lab 10 Supervised - Classification Models
Includes Logistic Regression, SVM, Decision Tree with metrics.
Uses Iris dataset by default so it runs without CSV.
"""
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report, precision_score, recall_score, f1_score

# ===================== CHANGE HERE =====================
USE_IRIS = True
TEST_SIZE = 0.2
# If using your own CSV, replace loading section with pd.read_csv and set X,y.
# =======================================================

iris = load_iris()
X = iris.data
y = iris.target

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=TEST_SIZE, random_state=42)

models = {
    "Logistic Regression": LogisticRegression(max_iter=200),
    "SVM RBF": SVC(kernel="rbf", C=1, gamma="scale"),
    "Decision Tree": DecisionTreeClassifier(random_state=42),
}

for name, model in models.items():
    print("\n====================", name, "====================")
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    print("Accuracy:", accuracy_score(y_test, y_pred))
    print("Precision:", precision_score(y_test, y_pred, average="weighted"))
    print("Recall:", recall_score(y_test, y_pred, average="weighted"))
    print("F1 Score:", f1_score(y_test, y_pred, average="weighted"))
    print("Confusion Matrix:\n", confusion_matrix(y_test, y_pred))
    print("Classification Report:\n", classification_report(y_test, y_pred))
