"""
Lab 10 Supervised Part A - K-Fold and LOOCV Cross Validation
Exam use: train-test validation alternative.
"""
import numpy as np
from sklearn.datasets import load_iris
from sklearn.model_selection import KFold, LeaveOneOut, cross_val_score
from sklearn.naive_bayes import GaussianNB

# ===================== CHANGE HERE =====================
iris = load_iris()
X = iris.data
y = iris.target
model = GaussianNB()
K = 5
# =======================================================

kf = KFold(n_splits=K, shuffle=True, random_state=42)
k_scores = cross_val_score(model, X, y, cv=kf, scoring="accuracy")
print("K-Fold Scores:", k_scores)
print("K-Fold Average Accuracy:", np.mean(k_scores))

# LOOCV can be slow on large datasets. Good for small datasets.
loo = LeaveOneOut()
loo_scores = cross_val_score(model, X, y, cv=loo, scoring="accuracy")
print("LOOCV Average Accuracy:", np.mean(loo_scores))
