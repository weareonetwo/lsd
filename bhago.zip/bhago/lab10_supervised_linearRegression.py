"""
Lab 10 Supervised Part B - Linear Regression
Exam use: regression flow + MSE/R2 error calculation.
"""
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

# ===================== CHANGE HERE =====================
# Simple sample: X is study hours, y is marks
X = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]).reshape(-1, 1)
y = np.array([35, 40, 50, 55, 60, 65, 70, 78, 85, 90])
TEST_SIZE = 0.2
# =======================================================

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=TEST_SIZE, random_state=42)

model = LinearRegression()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)

print("Predictions:", y_pred)
print("Actual:", y_test)
print("Mean Absolute Error:", mean_absolute_error(y_test, y_pred))
print("Mean Squared Error:", mean_squared_error(y_test, y_pred))
print("R2 Score:", r2_score(y_test, y_pred))
print("Slope:", model.coef_)
print("Intercept:", model.intercept_)
