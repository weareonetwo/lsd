"""
Lab 10 Fail-Safe: Leave-One-Out Cross Validation
Exam pattern: teacher asks LOOCV or K-Fold validation.
"""

from sklearn.datasets import load_iris
from sklearn.model_selection import LeaveOneOut, cross_val_score
from sklearn.tree import DecisionTreeClassifier

data = load_iris()
X = data.data
y = data.target

model = DecisionTreeClassifier(random_state=42)

loo = LeaveOneOut()
scores = cross_val_score(model, X, y, cv=loo)

print("Number of splits:", len(scores))
print("Average LOOCV Accuracy:", scores.mean())
