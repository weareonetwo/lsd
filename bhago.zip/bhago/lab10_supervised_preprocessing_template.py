"""
Lab 10 Supervised Part A - Data Preprocessing Template
Exam use: read dataset, missing values, encoding, train-test split.
"""
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder

# ===================== CHANGE HERE =====================
CSV_FILE = "data.csv"        # put your dataset file name here
TARGET_COLUMN = "target"     # put target/output column name here
TEST_SIZE = 0.2
# =======================================================

df = pd.read_csv(CSV_FILE)
print("Shape:", df.shape)
print(df.head())
print(df.info())
print("Missing values:\n", df.isnull().sum())

# Fill missing values: numeric with mean, categorical with mode
for col in df.columns:
    if df[col].dtype == "object":
        df[col] = df[col].fillna(df[col].mode()[0])
    else:
        df[col] = df[col].fillna(df[col].mean())

# Encode categorical columns
for col in df.select_dtypes(include=["object"]).columns:
    le = LabelEncoder()
    df[col] = le.fit_transform(df[col])

X = df.drop(columns=[TARGET_COLUMN])
y = df[TARGET_COLUMN]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=TEST_SIZE, random_state=42)
print("X_train:", X_train.shape)
print("X_test:", X_test.shape)
