"""
Lab 10 Fail-Safe: Regression Metrics
Exam pattern: train Linear Regression and calculate MSE/RMSE/MAE/R2.

CHANGE HERE:
- X and y
"""

import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

X = np.array([1, 2, 3, 4, 5, 6]).reshape(-1, 1)  # CHANGE HERE
y = np.array([2, 4, 6, 8, 10, 12])               # CHANGE HERE

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

model = LinearRegression()
model.fit(X_train, y_train)

y_pred = model.predict(X_test)

print("Predictions:", y_pred)
print("MSE:", mean_squared_error(y_test, y_pred))
print("RMSE:", mean_squared_error(y_test, y_pred) ** 0.5)
print("MAE:", mean_absolute_error(y_test, y_pred))
print("R2 Score:", r2_score(y_test, y_pred))
