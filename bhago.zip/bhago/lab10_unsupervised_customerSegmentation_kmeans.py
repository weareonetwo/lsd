"""
Lab 10 Unsupervised Task 01 - Customer Segmentation with K-Means
Runs clustering twice: without scaling and with scaling except age.
"""
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler, LabelEncoder

# ===================== CHANGE HERE =====================
# Replace this sample with pd.read_csv("Mall_Customers.csv") in exam if file is given.
df = pd.DataFrame({
    "customer_id": [1,2,3,4,5,6,7,8,9,10],
    "gender": ["Male","Female","Female","Male","Female","Male","Female","Male","Female","Male"],
    "age": [19,21,20,23,31,35,40,52,58,63],
    "annual_income": [15,16,17,18,40,45,60,70,80,90],
    "spending_score": [39,81,6,77,50,45,60,20,15,10],
})
DROP_COLUMNS = ["customer_id"]
AGE_COLUMN = "age"
K = 3
# =======================================================

work = df.drop(columns=DROP_COLUMNS).copy()
for col in work.select_dtypes(include=["object"]).columns:
    work[col] = LabelEncoder().fit_transform(work[col])

# 1) Without scaling
kmeans_raw = KMeans(n_clusters=K, random_state=42, n_init=10)
df["cluster_without_scaling"] = kmeans_raw.fit_predict(work)

# 2) With scaling except age
scaled = work.copy()
cols_to_scale = [c for c in scaled.columns if c != AGE_COLUMN]
scaler = StandardScaler()
scaled[cols_to_scale] = scaler.fit_transform(scaled[cols_to_scale])

kmeans_scaled = KMeans(n_clusters=K, random_state=42, n_init=10)
df["cluster_with_scaling_except_age"] = kmeans_scaled.fit_predict(scaled)

print(df)
print("\nInsight: Without scaling, large-value features dominate. With scaling, features contribute more equally except age.")
