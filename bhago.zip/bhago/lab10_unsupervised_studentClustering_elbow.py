"""
Lab 10 Unsupervised Task 03 - Student Clustering using K-Means + Elbow Method
Features: GPA, study_hours, attendance_rate.
"""
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans

# ===================== CHANGE HERE =====================
df = pd.DataFrame({
    "student_id": [101,102,103,104,105,106,107,108,109,110],
    "GPA": [3.8, 2.1, 3.2, 1.9, 3.6, 2.8, 3.9, 2.3, 3.0, 1.7],
    "study_hours": [20, 5, 14, 3, 18, 10, 22, 6, 12, 2],
    "attendance_rate": [92, 60, 80, 55, 88, 75, 95, 65, 78, 50],
})
FEATURES = ["GPA", "study_hours", "attendance_rate"]
K_RANGE = range(2, 7)
FINAL_K = 3  # after seeing elbow graph, change this if needed
# =======================================================

X = df[FEATURES]
X_scaled = StandardScaler().fit_transform(X)

wcss = []
for k in K_RANGE:
    model = KMeans(n_clusters=k, random_state=42, n_init=10)
    model.fit(X_scaled)
    wcss.append(model.inertia_)

plt.plot(list(K_RANGE), wcss, marker="o")
plt.title("Elbow Method for Student Clustering")
plt.xlabel("Number of Clusters K")
plt.ylabel("WCSS / Inertia")
plt.show()

kmeans = KMeans(n_clusters=FINAL_K, random_state=42, n_init=10)
df["cluster"] = kmeans.fit_predict(X_scaled)
print(df[["student_id", "GPA", "study_hours", "attendance_rate", "cluster"]])

plt.scatter(df["study_hours"], df["GPA"], c=df["cluster"])
plt.title("Student Clusters")
plt.xlabel("Study Hours")
plt.ylabel("GPA")
plt.show()
