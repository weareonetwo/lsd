"""
Lab 10 Unsupervised Task 02 - Vehicle Clustering with K-Means
Runs twice: without scaling and with scaling except vehicle_type categorical handling.
"""
import pandas as pd
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.cluster import KMeans

# ===================== CHANGE HERE =====================
data = {
    "vehicle_serial_no": [5, 3, 8, 2, 4, 7, 6, 10, 1, 9],
    "mileage": [150000, 120000, 250000, 80000, 100000, 220000, 180000, 300000, 75000, 280000],
    "fuel_efficiency": [15, 18, 10, 22, 20, 12, 16, 8, 24, 9],
    "maintenance_cost": [5000, 4000, 7000, 2000, 3000, 6500, 5500, 8000, 1500, 7500],
    "vehicle_type": ["SUV", "Sedan", "Truck", "Hatchback", "Sedan", "Truck", "SUV", "Truck", "Hatchback", "SUV"],
}
K = 3
CATEGORICAL_COL = "vehicle_type"
# =======================================================

df = pd.DataFrame(data)
work = df.copy()
work[CATEGORICAL_COL] = LabelEncoder().fit_transform(work[CATEGORICAL_COL])

# Without scaling
raw_model = KMeans(n_clusters=K, random_state=42, n_init=10)
df["cluster_without_scaling"] = raw_model.fit_predict(work)

# With scaling on numeric columns except categorical encoded vehicle_type
scaled = work.copy()
cols_to_scale = [c for c in scaled.columns if c != CATEGORICAL_COL]
scaled[cols_to_scale] = StandardScaler().fit_transform(scaled[cols_to_scale])

scaled_model = KMeans(n_clusters=K, random_state=42, n_init=10)
df["cluster_with_scaling"] = scaled_model.fit_predict(scaled)

print(df)
print("\nInsight: Scaling reduces dominance of mileage/maintenance_cost and gives fuel_efficiency more effect.")
