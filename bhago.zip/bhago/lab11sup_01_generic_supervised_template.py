"""
SUPERVISED LEARNING - GENERIC TEMPLATE

Use this for:
- Classification: spam/not spam, high/low, pass/fail, disease/no disease
- Regression: price prediction, marks prediction, salary prediction

Only change:
1. TASK_TYPE
2. MODEL_TYPE
3. Dataset
4. TARGET_COLUMN
5. FEATURES
6. NEW_SAMPLE if needed
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder

from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor
from sklearn.linear_model import LogisticRegression, LinearRegression

from sklearn.metrics import (
    accuracy_score, classification_report, confusion_matrix,
    mean_squared_error, mean_absolute_error, r2_score
)

np.random.seed(42)

# =========================
# 1. TASK AND MODEL - CHANGE HERE
# =========================

TASK_TYPE = "classification"  # "classification" or "regression"
MODEL_TYPE = "svm"            # classification: "svm", "decision_tree", "logistic"
                              # regression: "linear_regression", "decision_tree_regressor"

# =========================
# 2. DATASET - CHANGE HERE
# =========================

DATASET_MODE = "manual"  # "manual", "csv", or "random"
CSV_PATH = "data.csv"

if DATASET_MODE == "csv":
    df = pd.read_csv(CSV_PATH)

elif DATASET_MODE == "manual":
    df = pd.DataFrame({
        "total_spending": [1000, 8000, 500, 9000, 3000, 7000],
        "age": [20, 35, 19, 50, 28, 45],
        "num_visits": [3, 40, 2, 45, 10, 35],
        "purchase_frequency": [1, 20, 1, 25, 5, 18],
        "customer_type": ["New", "Old", "New", "Old", "New", "Old"],
        "high_value": [0, 1, 0, 1, 0, 1]
    })

else:
    n = 300
    df = pd.DataFrame({
        "word_frequency": np.random.rand(n),
        "email_length": np.random.randint(50, 1000, n),
        "has_hyperlinks": np.random.randint(0, 2, n),
        "sender_score": np.random.rand(n)
    })

    df["spam"] = (
        (df["word_frequency"] > 0.6) |
        ((df["has_hyperlinks"] == 1) & (df["sender_score"] < 0.3))
    ).astype(int)

print("\n--- Dataset Preview ---")
print(df.head())
print("Shape:", df.shape)

# =========================
# 3. TARGET AND FEATURES - CHANGE HERE
# =========================

TARGET_COLUMN = "high_value"

# None means all columns except target
FEATURES = None

if FEATURES is None:
    FEATURES = [col for col in df.columns if col != TARGET_COLUMN]

# =========================
# 4. HANDLE MISSING VALUES
# =========================

print("\nMissing values before:")
print(df.isnull().sum())

for col in df.columns:
    if df[col].dtype == "object":
        df[col] = df[col].fillna(df[col].mode()[0])
    else:
        df[col] = df[col].fillna(df[col].mean())

print("\nMissing values after:")
print(df.isnull().sum())

# =========================
# 5. ENCODE CATEGORICAL COLUMNS
# =========================

label_encoders = {}

for col in df.select_dtypes(include=["object"]).columns:
    le = LabelEncoder()
    df[col] = le.fit_transform(df[col])
    label_encoders[col] = le
    print(f"Encoded {col}:", dict(zip(le.classes_, le.transform(le.classes_))))

# =========================
# 6. SPLIT X AND y
# =========================

X = df[FEATURES]
y = df[TARGET_COLUMN]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# =========================
# 7. SCALE FEATURES
# =========================

APPLY_SCALING = True

if APPLY_SCALING:
    scaler = StandardScaler()
    X_train_final = scaler.fit_transform(X_train)
    X_test_final = scaler.transform(X_test)
else:
    scaler = None
    X_train_final = X_train
    X_test_final = X_test

# =========================
# 8. MODEL SELECTION
# =========================

if TASK_TYPE == "classification":
    if MODEL_TYPE == "svm":
        model = SVC(kernel="rbf", C=1, gamma="scale")
    elif MODEL_TYPE == "decision_tree":
        model = DecisionTreeClassifier(max_depth=4, random_state=42)
    elif MODEL_TYPE == "logistic":
        model = LogisticRegression(max_iter=1000)
    else:
        raise ValueError("Wrong classification model type")

elif TASK_TYPE == "regression":
    if MODEL_TYPE == "linear_regression":
        model = LinearRegression()
    elif MODEL_TYPE == "decision_tree_regressor":
        model = DecisionTreeRegressor(max_depth=4, random_state=42)
    else:
        raise ValueError("Wrong regression model type")

else:
    raise ValueError("TASK_TYPE should be classification or regression")

# =========================
# 9. TRAIN AND PREDICT
# =========================

model.fit(X_train_final, y_train)
y_pred = model.predict(X_test_final)

# =========================
# 10. EVALUATION
# =========================

if TASK_TYPE == "classification":
    print("\n--- Classification Evaluation ---")
    print("Accuracy:", accuracy_score(y_test, y_pred))
    print("\nConfusion Matrix:")
    print(confusion_matrix(y_test, y_pred))
    print("\nClassification Report:")
    print(classification_report(y_test, y_pred))

else:
    print("\n--- Regression Evaluation ---")
    mse = mean_squared_error(y_test, y_pred)
    rmse = mse ** 0.5
    mae = mean_absolute_error(y_test, y_pred)
    r2 = r2_score(y_test, y_pred)

    print("MSE:", mse)
    print("RMSE:", rmse)
    print("MAE:", mae)
    print("R2 Score:", r2)

    plt.scatter(y_test, y_pred)
    plt.xlabel("Actual")
    plt.ylabel("Predicted")
    plt.title("Actual vs Predicted")
    plt.show()

# =========================
# 11. PREDICT NEW SAMPLE - OPTIONAL
# =========================

NEW_SAMPLE = None

# Example:
# NEW_SAMPLE = pd.DataFrame({
#     "total_spending": [6000],
#     "age": [30],
#     "num_visits": [35],
#     "purchase_frequency": [15],
#     "customer_type": [1]
# })

if NEW_SAMPLE is not None:
    if APPLY_SCALING:
        NEW_SAMPLE_FINAL = scaler.transform(NEW_SAMPLE)
    else:
        NEW_SAMPLE_FINAL = NEW_SAMPLE

    prediction = model.predict(NEW_SAMPLE_FINAL)
    print("\nNew Sample Prediction:", prediction[0])
