"""
SUPERVISED LEARNING - SVM SPAM CLASSIFICATION

Question type:
Classify email as spam or not spam using SVM.

Minor changes:
- features
- spam rule
- new_email
"""

import numpy as np
import pandas as pd

from sklearn.svm import SVC
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

np.random.seed(42)

n = 500

df = pd.DataFrame({
    "word_frequency": np.random.rand(n),
    "email_length": np.random.randint(50, 1000, n),
    "has_hyperlinks": np.random.randint(0, 2, n),
    "sender_score": np.random.rand(n)
})

df["spam"] = (
    (df["word_frequency"] > 0.6) |
    ((df["has_hyperlinks"] == 1) & (df["sender_score"] < 0.3))
).astype(int)

X = df.drop("spam", axis=1)
y = df["spam"]

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, y, test_size=0.2, random_state=42
)

model = SVC(kernel="rbf", C=1, gamma="scale")
model.fit(X_train, y_train)

y_pred = model.predict(X_test)

print("Accuracy:", accuracy_score(y_test, y_pred))
print("\nConfusion Matrix:")
print(confusion_matrix(y_test, y_pred))
print("\nClassification Report:")
print(classification_report(y_test, y_pred, target_names=["Not Spam", "Spam"]))

# New email prediction
new_email = scaler.transform([[0.8, 200, 1, 0.1]])
result = model.predict(new_email)

print("\nNew email:", "SPAM" if result[0] == 1 else "NOT SPAM")
