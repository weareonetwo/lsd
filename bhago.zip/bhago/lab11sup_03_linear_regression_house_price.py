"""
SUPERVISED LEARNING - LINEAR REGRESSION HOUSE PRICE

Question type:
Predict continuous value like house price using Linear Regression.

Minor changes:
- features
- target
- new_house
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn.preprocessing import LabelEncoder

np.random.seed(42)

n = 200

df = pd.DataFrame({
    "square_footage": np.random.randint(500, 5000, n),
    "bedrooms": np.random.randint(1, 6, n),
    "bathrooms": np.random.randint(1, 4, n),
    "age": np.random.randint(0, 50, n),
    "neighborhood": np.random.choice(["Downtown", "Suburbs", "Rural"], n)
})

df["price"] = (
    df["square_footage"] * 150 +
    df["bedrooms"] * 10000 +
    df["bathrooms"] * 8000 -
    df["age"] * 500 +
    np.where(df["neighborhood"] == "Downtown", 50000,
    np.where(df["neighborhood"] == "Suburbs", 20000, 0)) +
    np.random.randint(-20000, 20000, n)
)

# Add missing values for practice
df.loc[np.random.choice(df.index, 10), "age"] = np.nan
df.loc[np.random.choice(df.index, 5), "bedrooms"] = np.nan

print("Missing before:")
print(df.isnull().sum())

df["age"] = df["age"].fillna(df["age"].mean())
df["bedrooms"] = df["bedrooms"].fillna(df["bedrooms"].median())

print("\nMissing after:")
print(df.isnull().sum())

le = LabelEncoder()
df["neighborhood_encoded"] = le.fit_transform(df["neighborhood"])

FEATURES = ["square_footage", "bedrooms", "bathrooms", "age", "neighborhood_encoded"]
TARGET = "price"

X = df[FEATURES]
y = df[TARGET]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

model = LinearRegression()
model.fit(X_train, y_train)

y_pred = model.predict(X_test)

mse = mean_squared_error(y_test, y_pred)
rmse = mse ** 0.5
mae = mean_absolute_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

print("\nRMSE:", rmse)
print("MAE:", mae)
print("R2 Score:", r2)

new_house = pd.DataFrame({
    "square_footage": [2000],
    "bedrooms": [3],
    "bathrooms": [2],
    "age": [10],
    "neighborhood_encoded": [le.transform(["Suburbs"])[0]]
})

prediction = model.predict(new_house)
print("\nPredicted price:", prediction[0])

plt.scatter(y_test, y_pred, alpha=0.6)
plt.xlabel("Actual Price")
plt.ylabel("Predicted Price")
plt.title("Actual vs Predicted House Price")
plt.show()
