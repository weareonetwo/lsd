"""
SUPERVISED LEARNING - CUSTOMER CLASSIFICATION USING SVM AND DECISION TREE

Question type:
Classify customer as high-value or low-value.
Compare SVM and Decision Tree.
"""

import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

np.random.seed(42)

n = 300

df = pd.DataFrame({
    "total_spending": np.random.randint(100, 10000, n),
    "age": np.random.randint(18, 70, n),
    "num_visits": np.random.randint(1, 50, n),
    "purchase_frequency": np.random.randint(1, 30, n)
})

df["high_value"] = (
    (df["total_spending"] > 5000) |
    (df["num_visits"] > 30)
).astype(int)

print("Missing values:", df.isnull().sum().sum())

X = df.drop("high_value", axis=1)
y = df["high_value"]

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, y, test_size=0.2, random_state=42
)

# SVM
svm = SVC(kernel="rbf", C=1, gamma="scale")
svm.fit(X_train, y_train)
svm_pred = svm.predict(X_test)

# Decision Tree
dt = DecisionTreeClassifier(max_depth=4, random_state=42)
dt.fit(X_train, y_train)
dt_pred = dt.predict(X_test)

print("\nSVM Accuracy:", accuracy_score(y_test, svm_pred))
print("Decision Tree Accuracy:", accuracy_score(y_test, dt_pred))

print("\nSVM Confusion Matrix:")
print(confusion_matrix(y_test, svm_pred))

print("\nDecision Tree Confusion Matrix:")
print(confusion_matrix(y_test, dt_pred))

print("\nSVM Report:")
print(classification_report(y_test, svm_pred, target_names=["Low-Value", "High-Value"]))

print("\nDecision Tree Report:")
print(classification_report(y_test, dt_pred, target_names=["Low-Value", "High-Value"]))
