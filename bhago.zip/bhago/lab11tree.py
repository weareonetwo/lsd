from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import (accuracy_score, confusion_matrix,
                             classification_report, precision_score,
                             recall_score, f1_score)
import pandas as pd

# ----------------------------
# 1. LOAD DATA (CHANGE THIS)
# ----------------------------
df = pd.read_csv("dataset_cleaned.csv")  # ← your cleaned csv

# ----------------------------
# 2. DEFINE FEATURES AND TARGET (CHANGE THIS)
# ----------------------------
X = df.drop(columns=['TARGET_ENC'])   # ← drop your target column
y = df['TARGET_ENC']                  # ← your target column

# ----------------------------
# 3. SPLIT DATA (never changes)
# ----------------------------
x_train, x_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)
print("Train size:", x_train.shape)
print("Test size:", x_test.shape)

# ----------------------------
# 4. TRAIN MODEL (never changes)
# ----------------------------
DT = DecisionTreeClassifier(random_state=42)
DT.fit(x_train, y_train)

# ----------------------------
# 5. PREDICT (never changes)
# ----------------------------
PredictionDT = DT.predict(x_test)
print("Predictions:", PredictionDT)

# ----------------------------
# 6. EVALUATE (never changes)
# ----------------------------

# Training accuracy
tracDT = DT.score(x_train, y_train)
print(f"Training Accuracy:  {tracDT * 100:.2f}%")

# Testing accuracy
teacDT = accuracy_score(y_test, PredictionDT)
print(f"Testing Accuracy:   {teacDT * 100:.2f}%")

# Confusion matrix
cm = confusion_matrix(y_test, PredictionDT)
print("Confusion Matrix:")
print(cm)

# Precision, Recall, F1
precision = precision_score(y_test, PredictionDT, average='weighted')
recall    = recall_score(y_test, PredictionDT, average='weighted')
f1        = f1_score(y_test, PredictionDT, average='weighted')
print(f"Precision: {precision:.4f}")
print(f"Recall:    {recall:.4f}")
print(f"F1 Score:  {f1:.4f}")

# Full report
print(classification_report(y_test, PredictionDT))