"""
UNSUPERVISED LEARNING - GENERIC KMEANS TEMPLATE

Use this for:
- Customer segmentation
- Student clustering
- Vehicle clustering
- Mall customer clustering
- Any clustering question where there is NO target/output column

Only change:
1. Dataset section
2. CATEGORICAL_COLUMNS
3. FEATURES
4. FINAL_K
5. PLOT_X and PLOT_Y
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler, LabelEncoder

np.random.seed(42)

# =========================
# 1. DATASET - CHANGE HERE
# =========================

DATASET_MODE = "manual"  # "manual", "csv", or "random"
CSV_PATH = "data.csv"

if DATASET_MODE == "csv":
    df = pd.read_csv(CSV_PATH)

elif DATASET_MODE == "manual":
    data = {
        "id": [1, 2, 3, 4, 5, 6],
        "age": [18, 22, 25, 40, 45, 50],
        "income": [20, 25, 30, 80, 90, 100],
        "score": [90, 85, 88, 30, 25, 20],
        "category": ["A", "A", "A", "B", "B", "B"]
    }
    df = pd.DataFrame(data)

else:
    n = 100
    df = pd.DataFrame({
        "student_id": range(1, n + 1),
        "GPA": np.round(np.random.uniform(1.5, 4.0, n), 2),
        "study_hours": np.round(np.random.uniform(1, 40, n), 1),
        "attendance_rate": np.round(np.random.uniform(40, 100, n), 1)
    })

print("\n--- Dataset Preview ---")
print(df.head())
print("Shape:", df.shape)

# =========================
# 2. ENCODE CATEGORICAL COLUMNS
# =========================

CATEGORICAL_COLUMNS = ["category"]  # CHANGE HERE

for col in CATEGORICAL_COLUMNS:
    if col in df.columns:
        le = LabelEncoder()
        df[col + "_encoded"] = le.fit_transform(df[col])
        print(f"Encoded {col}:", dict(zip(le.classes_, le.transform(le.classes_))))

# =========================
# 3. SELECT FEATURES
# =========================

FEATURES = ["age", "income", "score", "category_encoded"]  # CHANGE HERE
FEATURES = [col for col in FEATURES if col in df.columns]

X = df[FEATURES].copy()
print("\nFeatures used:", FEATURES)

# =========================
# 4. HANDLE MISSING VALUES
# =========================

for col in X.columns:
    if X[col].dtype == "object":
        X[col] = X[col].fillna(X[col].mode()[0])
    else:
        X[col] = X[col].fillna(X[col].mean())

# =========================
# 5. SCALE FEATURES
# =========================

APPLY_SCALING = True

if APPLY_SCALING:
    scaler = StandardScaler()
    X_final = scaler.fit_transform(X)
    print("Scaling applied")
else:
    X_final = X.values
    print("Scaling not applied")

# =========================
# 6. ELBOW METHOD
# =========================

K_RANGE = range(1, 8)

wcss = []
for k in K_RANGE:
    km = KMeans(n_clusters=k, init="k-means++", random_state=42, n_init=10)
    km.fit(X_final)
    wcss.append(km.inertia_)
    print(f"K={k}, WCSS={km.inertia_:.2f}")

plt.figure(figsize=(8, 5))
plt.plot(list(K_RANGE), wcss, marker="o")
plt.title("Elbow Method")
plt.xlabel("Number of Clusters K")
plt.ylabel("WCSS")
plt.grid(True, alpha=0.3)
plt.show()

# =========================
# 7. FINAL KMEANS
# =========================

FINAL_K = 3  # CHANGE HERE after elbow graph

kmeans = KMeans(n_clusters=FINAL_K, init="k-means++", random_state=42, n_init=10)
df["Cluster"] = kmeans.fit_predict(X_final)

print("\n--- Cluster Distribution ---")
print(df["Cluster"].value_counts().sort_index())

print("\n--- Cluster Averages ---")
numeric_features = [col for col in FEATURES if pd.api.types.is_numeric_dtype(df[col])]
print(df.groupby("Cluster")[numeric_features].mean().round(2))

# =========================
# 8. VISUALIZATION
# =========================

PLOT_X = "income"  # CHANGE HERE
PLOT_Y = "score"   # CHANGE HERE

if PLOT_X in df.columns and PLOT_Y in df.columns:
    plt.figure(figsize=(8, 6))
    for cluster in range(FINAL_K):
        mask = df["Cluster"] == cluster
        plt.scatter(df.loc[mask, PLOT_X], df.loc[mask, PLOT_Y], label=f"Cluster {cluster}")
    plt.title("KMeans Clustering Result")
    plt.xlabel(PLOT_X)
    plt.ylabel(PLOT_Y)
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.show()

print("\n--- Final Dataset ---")
print(df)
