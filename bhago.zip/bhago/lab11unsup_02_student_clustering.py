"""
UNSUPERVISED LEARNING - STUDENT CLUSTERING

Question type:
Cluster students based on GPA, study hours, and attendance.

Minor changes:
- n
- FEATURES
- FINAL_K
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

np.random.seed(42)

n = 100

df = pd.DataFrame({
    "student_id": range(1, n + 1),
    "GPA": np.round(np.random.uniform(1.5, 4.0, n), 2),
    "study_hours": np.round(np.random.uniform(1, 40, n), 1),
    "attendance_rate": np.round(np.random.uniform(40, 100, n), 1)
})

FEATURES = ["GPA", "study_hours", "attendance_rate"]

X = df[FEATURES]

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Elbow method
wcss = []
K_RANGE = range(2, 7)

for k in K_RANGE:
    km = KMeans(n_clusters=k, init="k-means++", random_state=42, n_init=10)
    km.fit(X_scaled)
    wcss.append(km.inertia_)
    print(f"K={k}, WCSS={km.inertia_:.2f}")

plt.plot(list(K_RANGE), wcss, marker="o")
plt.title("Elbow Method - Student Clustering")
plt.xlabel("K")
plt.ylabel("WCSS")
plt.grid(True, alpha=0.3)
plt.show()

FINAL_K = 3

kmeans = KMeans(n_clusters=FINAL_K, init="k-means++", random_state=42, n_init=10)
df["Cluster"] = kmeans.fit_predict(X_scaled)

print("\nCluster Distribution:")
print(df["Cluster"].value_counts().sort_index())

print("\nCluster Averages:")
print(df.groupby("Cluster")[FEATURES].mean().round(2))

plt.figure(figsize=(8, 6))
for cluster in range(FINAL_K):
    mask = df["Cluster"] == cluster
    plt.scatter(df.loc[mask, "study_hours"], df.loc[mask, "GPA"], label=f"Cluster {cluster}")

plt.title("Student Clustering")
plt.xlabel("Study Hours")
plt.ylabel("GPA")
plt.legend()
plt.grid(True, alpha=0.3)
plt.show()

print(df.head(20))
