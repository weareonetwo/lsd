"""
UNSUPERVISED LEARNING - VEHICLE CLUSTERING

Question type:
Cluster vehicles using mileage, fuel efficiency, maintenance cost, and type.

Minor changes:
- data dictionary
- FINAL_K
"""

import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler, LabelEncoder

data = {
    "vehicle_serial_no": [5, 3, 8, 2, 4, 7, 6, 10, 1, 9],
    "mileage": [150000, 120000, 250000, 80000, 100000, 220000, 180000, 300000, 75000, 280000],
    "fuel_efficiency": [15, 18, 10, 22, 20, 12, 16, 8, 24, 9],
    "maintenance_cost": [5000, 4000, 7000, 2000, 3000, 6500, 5500, 8000, 1500, 7500],
    "vehicle_type": ["SUV", "Sedan", "Truck", "Hatchback", "Sedan", "Truck", "SUV", "Truck", "Hatchback", "SUV"]
}

df = pd.DataFrame(data)

le = LabelEncoder()
df["type_encoded"] = le.fit_transform(df["vehicle_type"])

FEATURES = ["mileage", "fuel_efficiency", "maintenance_cost", "type_encoded"]
X = df[FEATURES]

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

wcss = []
K_RANGE = range(1, 8)

for k in K_RANGE:
    km = KMeans(n_clusters=k, init="k-means++", random_state=42, n_init=10)
    km.fit(X_scaled)
    wcss.append(km.inertia_)

plt.plot(list(K_RANGE), wcss, marker="o")
plt.title("Elbow Method - Vehicle Clustering")
plt.xlabel("K")
plt.ylabel("WCSS")
plt.grid(True, alpha=0.3)
plt.show()

FINAL_K = 3

kmeans = KMeans(n_clusters=FINAL_K, init="k-means++", random_state=42, n_init=10)
df["Cluster"] = kmeans.fit_predict(X_scaled)

print("\nCluster Distribution:")
print(df["Cluster"].value_counts().sort_index())

print("\nCluster Averages:")
print(df.groupby("Cluster")[["mileage", "fuel_efficiency", "maintenance_cost"]].mean().round(2))

plt.figure(figsize=(8, 6))
for cluster in range(FINAL_K):
    mask = df["Cluster"] == cluster
    plt.scatter(df.loc[mask, "mileage"], df.loc[mask, "fuel_efficiency"], label=f"Cluster {cluster}")

plt.title("Vehicle Clustering")
plt.xlabel("Mileage")
plt.ylabel("Fuel Efficiency")
plt.legend()
plt.grid(True, alpha=0.3)
plt.show()

print(df)
