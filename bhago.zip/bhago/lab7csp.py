from ortools.sat.python import cp_model

# ----------------------------
# 1. CREATE MODEL
# ----------------------------
model = cp_model.CpModel()

# ----------------------------
# 2. CREATE VARIABLES
# ----------------------------
# Integer variable → model.NewIntVar(min, max, 'name')
x = model.NewIntVar(0, 10, 'x')
y = model.NewIntVar(0, 10, 'y')
z = model.NewIntVar(0, 10, 'z')

# Boolean variable → only 0 or 1
b = model.NewBoolVar('b')

# ----------------------------
# 3. ADD CONSTRAINTS
# ----------------------------
# Basic math
model.Add(x + y <= 10)
model.Add(x != y)
model.Add(x == y)

# All must be different
model.AddAllDifferent([x, y, z])

# Allowed combinations only
model.AddAllowedAssignments([x, y], [(1, 2), (3, 4)])

# Forbidden combinations
model.AddForbiddenAssignments([x, y], [(1, 1), (2, 2)])

# Min and Max
min_var = model.NewIntVar(0, 10, 'min_var')
max_var = model.NewIntVar(0, 10, 'max_var')
model.AddMinEquality(min_var, [x, y, z])
model.AddMaxEquality(max_var, [x, y, z])

# Multiplication
product = model.NewIntVar(0, 100, 'product')
model.AddMultiplicationEquality(product, [x, y])

# Division
quotient = model.NewIntVar(0, 10, 'quotient')
model.AddDivisionEquality(quotient, x, y)   # quotient = x / y

# ----------------------------
# 4. SOLVE
# ----------------------------
solver = cp_model.CpSolver()
status = solver.Solve(model)

# ----------------------------
# 5. PRINT RESULT
# ----------------------------
status_map = {
    cp_model.OPTIMAL:    'OPTIMAL',
    cp_model.FEASIBLE:   'FEASIBLE',
    cp_model.INFEASIBLE: 'INFEASIBLE',
    cp_model.UNKNOWN:    'UNKNOWN'
}
print("Status:", status_map.get(status, 'UNKNOWN'))

if status == cp_model.OPTIMAL or status == cp_model.FEASIBLE:
    print("x =", solver.Value(x))
    print("y =", solver.Value(y))
    print("z =", solver.Value(z))
else:
    print("No solution found.")

# ----------------------------
# 6. PRINT ALL SOLUTIONS (optional)
# ----------------------------
solver2 = cp_model.CpSolver()
solution_printer = cp_model.VarArraySolutionPrinter([x, y, z])
solver2.parameters.enumerate_all_solutions = True
solver2.Solve(model, solution_printer)