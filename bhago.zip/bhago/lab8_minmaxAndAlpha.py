import math

# ----------------------------
# 1. NODE CLASS (never changes)
# ----------------------------
class Node:
    def __init__(self, value=None):
        self.value = value
        self.children = []
        self.minmax_value = None

# ----------------------------
# 2. BUILD YOUR TREE (always changes)
# ----------------------------
root = Node('A')

n1 = Node('B')
n2 = Node('C')
root.children = [n1, n2]

n3 = Node('D')
n4 = Node('E')
n5 = Node('F')
n6 = Node('G')
n1.children = [n3, n4]
n2.children = [n5, n6]

# leaf nodes — these have the actual numbers
n7  = Node(2)
n8  = Node(3)
n9  = Node(5)
n10 = Node(9)
n11 = Node(0)
n12 = Node(4)
n13 = Node(7)
n14 = Node(5)
n3.children = [n7,  n8 ]
n4.children = [n9,  n10]
n5.children = [n11, n12]
n6.children = [n13, n14]

# ----------------------------
# 3A. MINIMAX (use this OR 3B, not both)
# ----------------------------
def minimax(node, depth, maximizing_player=True):
    if depth == 0 or not node.children:
        return node.value

    if maximizing_player:
        value = -math.inf
        for child in node.children:
            value = max(value, minimax(child, depth-1, False))
        node.minmax_value = value
        return value
    else:
        value = math.inf
        for child in node.children:
            value = min(value, minimax(child, depth-1, True))
        node.minmax_value = value
        return value

# ----------------------------
# 3B. ALPHA BETA PRUNING (use this OR 3A, not both)
# ----------------------------
def alpha_beta(node, depth, alpha, beta, maximizing_player=True):
    if depth == 0 or not node.children:
        return node.value

    if maximizing_player:
        value = -math.inf
        for child in node.children:
            value = max(value, alpha_beta(child, depth-1, alpha, beta, False))
            alpha = max(alpha, value)
            if beta <= alpha:
                print("Pruned:", child.value)
                break
        node.minmax_value = value
        return value
    else:
        value = math.inf
        for child in node.children:
            value = min(value, alpha_beta(child, depth-1, alpha, beta, True))
            beta = min(beta, value)
            if beta <= alpha:
                print("Pruned:", child.value)
                break
        node.minmax_value = value
        return value

# ----------------------------
# 4. RUN (always changes based on 3A or 3B)
# ----------------------------

# if using minimax
minimax(root, 3)   # change depth to match your tree

# if using alpha beta
alpha_beta(root, 3, -math.inf, math.inf)   # change depth to match your tree

# ----------------------------
# 5. PRINT RESULTS (always changes)
# ----------------------------
print("Minimax values:")
print("A:", root.minmax_value)
print("B:", n1.minmax_value)
print("C:", n2.minmax_value)
print("D:", n3.minmax_value)
print("E:", n4.minmax_value)
print("F:", n5.minmax_value)
print("G:", n6.minmax_value)