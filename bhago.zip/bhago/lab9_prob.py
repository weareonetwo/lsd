!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

import random

suits = ['Hearts', 'Diamonds', 'Clubs', 'Spades']
ranks = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'Jack', 'Queen', 'King', 'Ace']
deck = [(rank, suit) for suit in suits for rank in ranks]
print(deck)

face_cards = [card for card in deck if card[0] in ['Jack', 'Queen', 'King']]
trials = 100000
king_given_face = 0

for _ in range(trials):
    card = random.choice(face_cards)
    if card[0] == 'King':
        king_given_face += 1


simulated_probability = king_given_face / trials


theoretical_probability = 4 / 12  # 4 Kings out of 12 face cards

print(f"Theoretical P(King | Face card): {theoretical_probability:.3f}")
print(f"Simulated P(King | Face card):   {simulated_probability:.3f}")




!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

from pgmpy.models import DiscreteBayesianNetwork
from pgmpy.factors.discrete import TabularCPD
from pgmpy.inference import VariableElimination

# ----------------------------
# 1. DEFINE NETWORK STRUCTURE
# ----------------------------
model = DiscreteBayesianNetwork([
    # ('Parent', 'Child')
    # Add all edges here
    ('A', 'B'),
    ('C', 'B'),
    ('B', 'D')
])

# ----------------------------
# 2. DEFINE CPDs (PROBABILITIES)
# ----------------------------

# Example Root Node CPD (no parents)
cpd_A = TabularCPD(
    variable='A',
    variable_card=2,
    values=[[0.8], [0.2]],
    state_names={'A': ['False', 'True']}
)

cpd_C = TabularCPD(
    variable='C',
    variable_card=2,
    values=[[0.7], [0.3]],
    state_names={'C': ['False', 'True']}
)

# Example Child Node CPD (with parents)
cpd_B = TabularCPD(
    variable='B',
    variable_card=2,
    values=[
        # A,F C,F   A,F C,T   A,T C,F   A,T C,T
        [0.9,       0.6,      0.5,      0.1],  # B=False
        [0.1,       0.4,      0.5,      0.9]   # B=True
    ],
    evidence=['A', 'C'],
    evidence_card=[2, 2],
    state_names={
        'B': ['False', 'True'],
        'A': ['False', 'True'],
        'C': ['False', 'True']
    }
)

# Another child node
cpd_D = TabularCPD(
    variable='D',
    variable_card=2,
    values=[
        [0.95, 0.2],
        [0.05, 0.8]
    ],
    evidence=['B'],
    evidence_card=[2],
    state_names={
        'D': ['False', 'True'],
        'B': ['False', 'True']
    }
)

# ----------------------------
# 3. ADD CPDs TO MODEL
# ----------------------------
model.add_cpds(cpd_A, cpd_C, cpd_B, cpd_D)

# ----------------------------
# 4. VALIDATE MODEL
# ----------------------------
assert model.check_model()

# ----------------------------
# 5. INFERENCE ENGINE
# ----------------------------
infer = VariableElimination(model)

# ----------------------------
# 6. QUERIES (REUSABLE BLOCK)
# ----------------------------

# P(Target | Evidence)
result = infer.query(
    variables=['B'],
    evidence={'A': 'True'}
)

print(result)
print("P(B=True | A=True):", result.values[1])

# Another example query
result2 = infer.query(
    variables=['D'],
    evidence={'B': 'True'}
)

print("P(D=True | B=True):", result2.values[1])



!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! HIDDEN MARKOV MODEL !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

import numpy as np

# ----------------------------
# 1. STATES
# ----------------------------
states = ["S1", "S2", "S3"]

# ----------------------------
# 2. TRANSITION MATRIX
# (rows = current state, cols = next state)
# ----------------------------
transition_matrix = np.array([
    [0.5, 0.3, 0.2],  # from S1
    [0.2, 0.5, 0.3],  # from S2
    [0.3, 0.3, 0.4]   # from S3
])

# ----------------------------
# 3. SIMULATION FUNCTION
# ----------------------------
def simulate_markov(initial_state, num_steps):
    current_state = initial_state
    sequence = [current_state]

    for _ in range(num_steps):
        idx = states.index(current_state)

        next_state = np.random.choice(states, p=transition_matrix[idx])

        sequence.append(next_state)
        current_state = next_state

    return sequence

# ----------------------------
# 4. RUN SIMULATION
# ----------------------------
initial_state = "S1"
num_steps = 10

result = simulate_markov(initial_state, num_steps)

print("State sequence:")
print(" -> ".join(result))











